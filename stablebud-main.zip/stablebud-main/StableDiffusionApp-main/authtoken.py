auth_token = "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"
# How to get one: https://huggingface.co/docs/hub/security-tokens